﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FootBallPlayerOPG;

namespace Opgave_4.Controllers
{
    private IManageFootballPlayers mgr = new ManageFootballPlayer();

    [HttpGet]
    public IEnumerable<FootballPlayer> Get()
    {
    return mgr.Get();
}

[HttpGet]
[Route("{id}")]
public IEnumerable<FootballPlayer> Get(int id)
{
    return mgr.Get();
}

[HttpPost]
public bool Post([FromBody] FootballPlayer footballPlayer)
{
    return mgr.Create(footballPlayer);
}

[HttpPut]
[Route("{id}")]
public bool Put(int id, [FromBody] FootballPlayer footballPlayer)
{
    return mgr.Update(id, footballPlayer);
}

[HttpPut]
[Route("{id}")]
public FootballPlayer Delete(int id)
{
    return mgr.Delete(id);
}
}
}