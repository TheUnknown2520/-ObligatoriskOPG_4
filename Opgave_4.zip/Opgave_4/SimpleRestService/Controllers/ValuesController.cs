﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ObligatoriskOPG;
using SimpleRestService.Managers;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SimpleRestService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private IManageItems mgr = new ManageItem();

        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<FootballPlayer> Get()
        {
            return mgr.Get();
        }

        [HttpGet("{id}")]
        public IEnumerable<FootballPlayer> Get(int id)
        {
            return mgr.Get();
        }
        // GET api/<ValuesController>/5

        // POST api/<ValuesController>
        [HttpPost]
        public bool Post([FromBody] FootballPlayer footballPlayer)
        {
            return mgr.Create(footballPlayer);
        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public bool Put(int id, [FromBody] FootballPlayer footballPlayer)
        {
            return mgr.Update(id, footballPlayer);
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public FootballPlayer Delete(int id)
        {
            return mgr.Delete(id);
        }

    }
}
