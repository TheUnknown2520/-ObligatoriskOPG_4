﻿using ObligatoriskOPG;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleRestService.Managers
{
    public interface IManageItems
    {
        IEnumerable<FootballPlayer> Get();

        FootballPlayer Get(int id);

        bool Create(FootballPlayer footballPlayer);
        bool Update(int id, FootballPlayer footballPlayer);
        FootballPlayer Delete(int id);
    }
}
