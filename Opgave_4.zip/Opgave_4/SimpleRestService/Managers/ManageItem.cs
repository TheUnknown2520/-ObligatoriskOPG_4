﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ObligatoriskOPG;

namespace SimpleRestService.Managers
{
    public class ManageItem : IManageItems
    {
        private static List<FootballPlayer> data = new List<FootballPlayer>()
        {
            new FootballPlayer(1, "Christopher", 200, 1),
            new FootballPlayer(2, "Messi", 210.0000, 2)
        };

        public ManageItem()
        {

        }

        public IEnumerable<FootballPlayer> Get()
        {
            return new List<FootballPlayer>(data);
        }

        public FootballPlayer Get(int id)
        {
            return data.Find(d => d.Id == id);
        }

        public bool Create(FootballPlayer footballPlayer)
        {
            data.Add(footballPlayer);
            return true;
        }

        public bool Update(int id, FootballPlayer footballPlayer)
        {
            throw new NotImplementedException();
        }

        public FootballPlayer Delete(int id)
        {
            FootballPlayer d = Get(id);
            data.Remove(d);
            return d;
        }
    }
}
